import os
import logging
import shutil
import re
from datetime import datetime, timedelta
from airflow import DAG, AirflowException
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from psycopg2.extras import execute_values
import pandas as pd


########################################################
#
#   DAG Settings
#
#########################################################

dag_default_args = {
    'owner': 'Siddharth Suresh Nair',
    'start_date': datetime(2024, 1, 1),
    'retries': 0,
    'depends_on_past': False,
    'wait_for_downstream': False,
}

bronze_schema_creation_dag = DAG(
    dag_id = 'bronze_schema_creation_dag',
    default_args = dag_default_args,
    schedule_interval = None,
    catchup = False,
    max_active_runs = 1,
    concurrency = 5
)

#########################################################
#
#   Custom Logics for Operator
#
#########################################################

# 1. Function to list all CSV files in the local directory

def list_local_files_func(**kwargs):
    """List all CSV files in /home/airflow/gcs/data and return full paths."""

    # Define the directory to search for CSV files
    data_folder = "/home/airflow/gcs/data"
    archive_folder_name = "archive"
    logging.info(f"Looking for files in: {data_folder}")

    # If the directory does not exist, log an error and raise an exception
    if not os.path.exists(data_folder):
        logging.info("Directory does not exist")
        raise FileNotFoundError(f"{data_folder} not found")

    # Initialize a list to hold file paths
    all_files = []

    # Walk through the directory and its subdirectories
    for root, dirs, files in os.walk(data_folder):

        # Skip the archive folder
        if archive_folder_name in dirs:
            dirs.remove(archive_folder_name)

        for file in files:
            if file.endswith(".csv"):
                full_path = os.path.join(root, file)
                logging.info(f"Found file: {full_path}")
                all_files.append(full_path)
    
    # Return the list of csv file paths
    logging.info(f"Total CSV files found: {all_files}")
    return all_files
    

        


def load_to_postgres(**kwargs):
    """Load CSV data into corresponding Postgres tables in the bronze schema."""

    # Retrieve the list of files from XCom
    ti = kwargs["ti"]
    files = ti.xcom_pull(task_ids="list_files_task")
    logging.info(f"Files to process: {files}")

    # If no files are found, raise an exception
    if not files:
        raise ValueError("No files found in XCom from list_files_task")
    
    base_dir = "/home/airflow/gcs/data"
    archive_dir = os.path.join(base_dir, "archive")
    os.makedirs(archive_dir, exist_ok=True)
    
    # Mapping between file-paths and DB tables
    table_map = {
        "05_2020.csv": "bronze.airbnb",
        "06_2020.csv": "bronze.airbnb",
        "07_2020.csv": "bronze.airbnb",
        "08_2020.csv": "bronze.airbnb",
        "09_2020.csv": "bronze.airbnb",
        "10_2020.csv": "bronze.airbnb",
        "11_2020.csv": "bronze.airbnb",
        "12_2020.csv": "bronze.airbnb",
        "01_2021.csv": "bronze.airbnb",
        "02_2021.csv": "bronze.airbnb",
        "03_2021.csv": "bronze.airbnb",
        "04_2021.csv": "bronze.airbnb",
        "2016Census_G01_NSW_LGA.csv": "bronze.census_g01",
        "2016Census_G02_NSW_LGA.csv": "bronze.census_g02",
        "NSW_LGA_CODE.csv": "bronze.lga_code",
        "NSW_LGA_SUBURB.csv": "bronze.lga_suburb"
    }

    # Postgres connection
    hook = PostgresHook(postgres_conn_id="postgres")
    conn = hook.get_conn()
    cursor = conn.cursor()

    # Process each file
    for file_path in files:
        # Extract filename and corresponding table name
        filename = os.path.basename(file_path)
        table_name = table_map.get(filename)

        file_month = re.sub(r'\.csv$', '', filename)

        # Log the start of processing
        logging.info(f"Loading {filename} into {table_name}")

        try:
            # Read CSV into DataFrame
            df = pd.read_csv(file_path)
            # Drop completely empty columns
            df = df.dropna(axis=1, how='all')
            # Standardize column names: lowercase and strip whitespace
            df.columns = [col.lower().strip() for col in df.columns]
            # Add file_month column dynamically
            if table_name == "bronze.airbnb":
                df['file_month'] = file_month
            # Get list of columns
            df_columns = list(df.columns)
            logging.info(f"DataFrame columns: {df_columns}")
            # Convert NaN to None for PostgreSQL
            df = df.where(pd.notnull(df), None)

            try:
                # Insert data into Postgres dynamically
                logging.info(f"Inserting {len(df)} rows into {table_name}")
                values = [tuple(x) for x in df.to_numpy()]
                logging.info(f"First 5 rows to insert: {values[:5]}")
                # Create insert query dynamically
                insert_query = f"INSERT INTO {table_name} ({', '.join(df_columns)}) VALUES %s"
                # Use execute_values for efficient bulk insert
                execute_values(cursor, insert_query, values, page_size=1000)
                logging.info(f"Executed insert query for {table_name}")
                # Commit the transaction
                conn.commit()
                logging.info(f" Successfully inserted {len(df)} rows into {table_name}")

                # Verify insertion by counting rows
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count_after = cursor.fetchone()[0]
                logging.info(f"Successfully inserted {len(df)} rows into {table_name}. Total rows: {count_after}")

                # Move processed file to archive
                archive_path = os.path.join(archive_dir, filename)
                shutil.move(file_path, archive_path)
                logging.info(f"Moved {filename} to {archive_path}")

            except Exception as e:
                # Log any errors during insertion
                logging.error(f"Error inserting data into {table_name}: {e}")
                conn.rollback()

        except Exception as e:
            # Log any errors during file processing
            logging.error(f"Error processing file {filename}: {e}")

    cursor.close()
    conn.close()

#########################################################
#
#   DAG Operator Setup
#
#########################################################

# 1. Task to list all CSV files in the local directory

list_files_task = PythonOperator(
    task_id="list_files_task",
    python_callable = list_local_files_func,
    provide_context = True,
    dag = bronze_schema_creation_dag
)

# 2. Task to load CSV data into Postgres tables
load_postgres_task = PythonOperator(
    task_id="load_postgres_task",
    python_callable = load_to_postgres,
    provide_context = True,
    dag = bronze_schema_creation_dag,
)

# Setting up task dependencies
list_files_task >> load_postgres_task