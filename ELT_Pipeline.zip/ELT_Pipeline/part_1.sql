-- CREATE THE BRONZE SCHEMA
create schema if not exists bronze;

-- CREATE THE RAW TABLE FOR AIRBNB LISTINGS
create table if not exists bronze.airbnb (
	listing_id bigint,
	scrape_id bigint,
	scraped_date text,
	host_id bigint,
	host_name text,
	host_since text,
	host_is_superhost text,
	host_neighbourhood text,
	listing_neighbourhood text,
	property_type text,
	room_type text,
	accommodates bigint,
	price bigint,
	has_availability text,
	availability_30 bigint,
	number_of_reviews bigint,
	review_scores_rating float,
	review_scores_accuracy float,
	review_scores_cleanliness float,
	review_scores_checkin float,
	review_scores_communication float,
	review_scores_value float,
	file_month text
);


-- CREATE THE RAW TABLE FOR CENSUS G01
create table if not exists bronze.census_g01 (
    lga_code_2016 text,
    tot_p_m bigint,
    tot_p_f bigint,
    tot_p_p bigint,
    age_0_4_yr_m bigint,
    age_0_4_yr_f bigint,
    age_0_4_yr_p bigint,
    age_5_14_yr_m bigint,
    age_5_14_yr_f bigint,
    age_5_14_yr_p bigint,
    age_15_19_yr_m bigint,
    age_15_19_yr_f bigint,
    age_15_19_yr_p bigint,
    age_20_24_yr_m bigint,
    age_20_24_yr_f bigint,
    age_20_24_yr_p bigint,
    age_25_34_yr_m bigint,
    age_25_34_yr_f bigint,
    age_25_34_yr_p bigint,
    age_35_44_yr_m bigint,
    age_35_44_yr_f bigint,
    age_35_44_yr_p bigint,
    age_45_54_yr_m bigint,
    age_45_54_yr_f bigint,
    age_45_54_yr_p bigint,
    age_55_64_yr_m bigint,
    age_55_64_yr_f bigint,
    age_55_64_yr_p bigint,
    age_65_74_yr_m bigint,
    age_65_74_yr_f bigint,
    age_65_74_yr_p bigint,
    age_75_84_yr_m bigint,
    age_75_84_yr_f bigint,
    age_75_84_yr_p bigint,
    age_85ov_m bigint,
    age_85ov_f bigint,
    age_85ov_p bigint,
    counted_census_night_home_m bigint,
    counted_census_night_home_f bigint,
    counted_census_night_home_p bigint,
    count_census_nt_ewhere_aust_m bigint,
    count_census_nt_ewhere_aust_f bigint,
    count_census_nt_ewhere_aust_p bigint,
    indigenous_psns_aboriginal_m bigint,
    indigenous_psns_aboriginal_f bigint,
    indigenous_psns_aboriginal_p bigint,
    indig_psns_torres_strait_is_m bigint,
    indig_psns_torres_strait_is_f bigint,
    indig_psns_torres_strait_is_p bigint,
    indig_bth_abor_torres_st_is_m bigint,
    indig_bth_abor_torres_st_is_f bigint,
    indig_bth_abor_torres_st_is_p bigint,
    indigenous_p_tot_m bigint,
    indigenous_p_tot_f bigint,
    indigenous_p_tot_p bigint,
    birthplace_australia_m bigint,
    birthplace_australia_f bigint,
    birthplace_australia_p bigint,
    birthplace_elsewhere_m bigint,
    birthplace_elsewhere_f bigint,
    birthplace_elsewhere_p bigint,
    lang_spoken_home_eng_only_m bigint,
    lang_spoken_home_eng_only_f bigint,
    lang_spoken_home_eng_only_p bigint,
    lang_spoken_home_oth_lang_m bigint,
    lang_spoken_home_oth_lang_f bigint,
    lang_spoken_home_oth_lang_p bigint,
    australian_citizen_m bigint,
    australian_citizen_f bigint,
    australian_citizen_p bigint,
    age_psns_att_educ_inst_0_4_m bigint,
    age_psns_att_educ_inst_0_4_f bigint,
    age_psns_att_educ_inst_0_4_p bigint,
    age_psns_att_educ_inst_5_14_m bigint,
    age_psns_att_educ_inst_5_14_f bigint,
    age_psns_att_educ_inst_5_14_p bigint,
    age_psns_att_edu_inst_15_19_m bigint,
    age_psns_att_edu_inst_15_19_f bigint,
    age_psns_att_edu_inst_15_19_p bigint,
    age_psns_att_edu_inst_20_24_m bigint,
    age_psns_att_edu_inst_20_24_f bigint,
    age_psns_att_edu_inst_20_24_p bigint,
    age_psns_att_edu_inst_25_ov_m bigint,
    age_psns_att_edu_inst_25_ov_f bigint,
    age_psns_att_edu_inst_25_ov_p bigint,
    high_yr_schl_comp_yr_12_eq_m bigint,
    high_yr_schl_comp_yr_12_eq_f bigint,
    high_yr_schl_comp_yr_12_eq_p bigint,
    high_yr_schl_comp_yr_11_eq_m bigint,
    high_yr_schl_comp_yr_11_eq_f bigint,
    high_yr_schl_comp_yr_11_eq_p bigint,
    high_yr_schl_comp_yr_10_eq_m bigint,
    high_yr_schl_comp_yr_10_eq_f bigint,
    high_yr_schl_comp_yr_10_eq_p bigint,
    high_yr_schl_comp_yr_9_eq_m bigint,
    high_yr_schl_comp_yr_9_eq_f bigint,
    high_yr_schl_comp_yr_9_eq_p bigint,
    high_yr_schl_comp_yr_8_belw_m bigint,
    high_yr_schl_comp_yr_8_belw_f bigint,
    high_yr_schl_comp_yr_8_belw_p bigint,
    high_yr_schl_comp_d_n_g_sch_m bigint,
    high_yr_schl_comp_d_n_g_sch_f bigint,
    high_yr_schl_comp_d_n_g_sch_p bigint,
    count_psns_occ_priv_dwgs_m bigint,
    count_psns_occ_priv_dwgs_f bigint,
    count_psns_occ_priv_dwgs_p bigint,
    count_persons_other_dwgs_m bigint,
    count_persons_other_dwgs_f bigint,
    count_persons_other_dwgs_p bigint
);



-- CREATE THE RAW TABLE FOR CENSUS G02
create table if not exists bronze.census_g02 (
	lga_code_2016 text,
	median_age_persons bigint,
	median_mortgage_repay_monthly bigint,
	median_tot_prsnl_inc_weekly bigint,
	median_rent_weekly bigint,
	median_tot_fam_inc_weekly bigint,
	average_num_psns_per_bedroom float,
	median_tot_hhd_inc_weekly bigint,
	average_household_size float
);

-- CREATE THE RAW TABLE FOR LGA CODE AND NAME MAPPING
create table if not exists bronze.lga_code (
	lga_code text,
	lga_name text
);

-- CREATE THE RAW TABLE FOR LGA NAME AND SUBURB MAPPING
create table if not exists bronze.lga_suburb(
	lga_name text,
	suburb_name text
);


select count(*) from bronze.airbnb;
select count(*) from bronze.census_g02;
select count(*) from bronze.census_g01;
select count(*) from bronze.lga_code;
select count(*) from bronze.lga_suburb;