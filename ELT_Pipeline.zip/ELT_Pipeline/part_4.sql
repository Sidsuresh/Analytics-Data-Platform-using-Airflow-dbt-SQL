
-----------------------------------------------------------------------------------------
-- a. 

with lga_revenue as (
	select 
		ln.listing_neighbourhood as lga,
		round(avg(ln.avg_estimated_revenue_per_active_listing)::numeric * 12, 3) as estimated_annual_avg_revenue
	from gold.dm_listing_neighbourhood ln
	group by ln.listing_neighbourhood 
),
ranked as (
	select
		*,
		rank() over (order by estimated_annual_avg_revenue asc) as lowest_rank,
		rank() over (order by estimated_annual_avg_revenue desc) as highest_rank
	from lga_revenue
),
selected_countries as (
	select 
		*
	from ranked
	where lowest_rank <= 3 or highest_rank <= 3
),
addlga as (
	select 
		l.lga_code as lga_code_2016,
		s.lga,
		s.estimated_annual_avg_revenue,
		case
            when s.highest_rank <= 3 then concat('highest_rev_', s.highest_rank)
            when s.lowest_rank <= 3 then concat('lowest_rev_', s.lowest_rank)
        end as rank
	from selected_countries s
	left join gold.dim_lga l
	on s.lga = l.lga_name
),
census_metric_dist as (
	select
		*
	from gold.census_g01 g1
	left join gold.census_g02 g2
	using (lga_code_2016)
)
select *
from addlga al
left join census_metric_dist cm
using (lga_code_2016);


-----------------------------------------------------------------------------
-- b.
with lga_revenue as (
	select 
		ln.listing_neighbourhood as lga,
		round(avg(ln.avg_estimated_revenue_per_active_listing)::numeric, 3) as avg_revenue_per_active_listing
	from gold.dm_listing_neighbourhood ln
	group by ln.listing_neighbourhood 
),
addlga as (
	select 
		l.lga_code as lga_code_2016,
		r.lga,
		r.avg_revenue_per_active_listing
	from lga_revenue r
	left join gold.dim_lga l
	on r.lga = l.lga_name
), 
comp as (
	select 
		a.*,
		cg.median_age_persons
	from addlga a
	left join gold.census_g02 cg
	using (lga_code_2016)
)
select * from comp order by avg_revenue_per_active_listing desc; -- To get the dataframe comparing the average revenue and median age for each LGA
--select corr(avg_revenue_per_active_listing, median_age_persons) from comp; -- To get the correlation value


------------------------------------------------------------------------------------------
-- c.
with lga_revenue as (
	select 
		ln.listing_neighbourhood, round(avg(ln.avg_estimated_revenue_per_active_listing)::numeric, 3) as avg_revenue_per_active_listing
	from gold.dm_listing_neighbourhood ln
	group by ln.listing_neighbourhood 
), 
rank_lga as (
	select
		*,
		rank() over (order by avg_revenue_per_active_listing desc) as top_performing_lga
	from lga_revenue
),
top_5_performing_lga as (
	select *
	from rank_lga
	where top_performing_lga <= 5
), 
stays_by_listing_type as (
	select
		d.listing_neighbourhood, d.property_type, d.room_type, f.accommodates,
	    sum(30 - f.availability_30) filter (where f.has_availability = true) as total_stays_active_listings
	from gold.fact_airbnb f
	left join gold.dim_property d
		on f.listing_id = d.listing_id
	    and f.scraped_date >= d.valid_from
	    and f.scraped_date < coalesce(d.valid_to, '9999-12-31'::timestamp)
	inner join top_5_performing_lga t
		using (listing_neighbourhood)
	group by listing_neighbourhood, d.property_type, d.room_type, f.accommodates
	order by listing_neighbourhood, total_stays_active_listings desc
),
ranked as (
	select
		*,
		rank() over (partition by listing_neighbourhood order by total_stays_active_listings desc) as property_type_rank
	from stays_by_listing_type
),
best_listing_type as (
	select
		listing_neighbourhood, property_type, room_type, accommodates, total_stays_active_listings
	from ranked
	where property_type_rank = 1
)
select
	listing_neighbourhood, avg_revenue_per_active_listing, property_type, room_type, accommodates, total_stays_active_listings
from top_5_performing_lga
left join best_listing_type
using (listing_neighbourhood)
order by top_performing_lga;


------------------------------------------------------------------------------------------
--d. 

with host_multiple_properties as (
	select
		f.host_id, count(distinct f.listing_id) as listing_count
	from gold.fact_airbnb f
	group by f.host_id
	having count(distinct f.listing_id) > 1 and f.host_id != 0
	order by f.host_id
),
host_multiple_properties_listing_lga as (
	 select 
		h.host_id, h.listing_count, count(distinct f.lga_code) as distinct_lga_count
	from  host_multiple_properties h
	join gold.fact_airbnb f
		on h.host_id = f.host_id
	group by h.host_id, h.listing_count
	order by h.host_id
)
select
	*,
	case
        when distinct_lga_count = 1 then 'Concentrated (Single LGA)'
        else 'Distributed (Multiple LGAs)'
    end as concentration_status
from host_multiple_properties_listing_lga
order by distinct_lga_count desc, listing_count desc;


------------------------------------------------------------------------------------------
-- e.


with host_single_properties as (
	select
		f.host_id, count(distinct f.listing_id) as listing_count
	from gold.fact_airbnb f
	group by f.host_id
	having count(distinct f.listing_id) = 1 and f.host_id != 0
	order by f.host_id
), annualrev as (
	select
		max(f.host_id) as host_id, f.listing_id, max(f.lga_code) as lga_code_2016,
		round(avg(case when f.has_availability = 't' then (30 - f.availability_30) * f.price else 0 end) * 12, 3) as estimated_annual_revenue
	from gold.fact_airbnb f
	inner join host_single_properties p
		on f.host_id = p.host_id
	group by f.listing_id, f.host_id
	order by f.host_id
), annualmortgage as (
	select 
		cg.lga_code_2016, 
		cg.median_mortgage_repay_monthly * 12 as annualised_median_mortgage_repay
	from gold.census_g02 cg
), hostcoverage as (
	select
		r.host_id, r.listing_id, r.lga_code_2016, r.estimated_annual_revenue, m.annualised_median_mortgage_repay,
		case
			when r.estimated_annual_revenue >= m.annualised_median_mortgage_repay then 1
			else 0
		end as covers_mortgage_flag
	from annualrev r
	left join annualmortgage m
	using (lga_code_2016)
), coveragepct as (
	select
		lga_code_2016 as lga_code, sum(h.covers_mortgage_flag) as total_host_covering_mortgage, count(h.covers_mortgage_flag) as total_single_hosts_lga,
		round(sum(h.covers_mortgage_flag)::numeric * 100 / count(h.covers_mortgage_flag), 3) as coverage_pct
	from hostcoverage h
	group by h.lga_code_2016
)
select
	lga_code, lga_name, total_single_hosts_lga, coverage_pct 
from coveragepct c
left join gold.dim_lga d
using (lga_code)
order by coverage_pct desc
limit 1;
