{% snapshot suburb_snapshot %}

{{
    config(
        unique_key='suburb_id',
        strategy='check',
        check_cols=['suburb_name', 'lga_name']
    )
}}

with source as (
    select * from {{source("raw", "lga_suburb")}}
)

select
    {{ dbt_utils.generate_surrogate_key(['initcap(trim(lga_name))', 'initcap(trim(suburb_name))']) }} as suburb_id,
    initcap(trim(lga_name)) as lga_name,
    initcap(trim(suburb_name)) as suburb_name
from source
order by lga_name, suburb_name

{% endsnapshot %}
