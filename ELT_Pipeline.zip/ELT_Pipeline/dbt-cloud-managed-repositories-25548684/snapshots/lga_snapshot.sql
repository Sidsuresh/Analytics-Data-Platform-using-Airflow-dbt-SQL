{% snapshot lga_snapshot %}

{{
    config(
        unique_key='lga_code',
        strategy='check',
        check_cols=['lga_name']
    )
}}

with source as (
    select * from {{source("raw", "lga_code")}}
)

select
    upper(trim(concat('LGA', trim(lga_code)))) as lga_code,
    initcap(trim(lga_name)) as lga_name
from source
order by lga_code

{% endsnapshot %}
