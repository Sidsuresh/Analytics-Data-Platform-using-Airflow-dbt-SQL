{% snapshot host_snapshot %}

{{
    config(
        unique_key='host_id',
        strategy = 'timestamp',
        updated_at = 'scraped_date',
        invalidate_hard_deletes = True
    )
}}

with source as (
    select *,
        cast(split_part(file_month, '_', 2) as integer) as file_year,
        cast(split_part(file_month, '_', 1) as integer) as file_month_num
    from {{source('raw', 'airbnb')}}
),

cleaned as (
    select 
        coalesce(cast(host_id as bigint), 0) as host_id,
        coalesce(trim(host_name), 'Unknown Host')::text as host_name,
        case
            when lower(trim(host_is_superhost)) = 't' then true
            when lower(trim(host_is_superhost)) = 'f' then false
            else false
        end::boolean as host_is_superhost,
        coalesce(initcap(trim(host_neighbourhood)), 'No Usual Address')::text as host_neighbourhood,
        to_date(nullif(trim(scraped_date), ''), 'YYYY-MM-DD') as scraped_date
    from source
    where extract(month from to_date(scraped_date, 'YYYY-MM-DD')) = file_month_num
        and extract(year from to_date(scraped_date, 'YYYY-MM-DD')) = file_year
)

select 
    distinct on (host_id) *
from cleaned
order by host_id, scraped_date desc

{% endsnapshot %}