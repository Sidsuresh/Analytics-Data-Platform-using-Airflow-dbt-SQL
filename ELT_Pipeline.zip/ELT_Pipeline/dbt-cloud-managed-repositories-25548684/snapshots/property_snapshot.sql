{% snapshot property_snapshot %}
{{
    config(
        unique_key='listing_id',
        strategy = 'timestamp',
        updated_at = 'scraped_date'
    )

}}

with source as (
    select *,
        cast(split_part(file_month, '_', 2) as integer) as file_year,
        cast(split_part(file_month, '_', 1) as integer) as file_month_num
    from {{source('raw', 'airbnb')}}
), 

cleaned as (
    select
        cast(listing_id as bigint) as listing_id,
        coalesce(initcap(trim(property_type)), 'Unknown Property Type')::text as property_type,
        coalesce(initcap(trim(room_type)), 'Unknown Room Type')::text as room_type,
        coalesce(initcap(trim(listing_neighbourhood)), 'No Usual Address')::text as listing_neighbourhood,
        coalesce(cast(host_id as bigint), 0) as host_id,
        to_date(nullif(trim(scraped_date), ''), 'YYYY-MM-DD') as scraped_date
    from source
    where extract(month from to_date(scraped_date, 'YYYY-MM-DD')) = file_month_num
        and extract(year from to_date(scraped_date, 'YYYY-MM-DD')) = file_year
)

select * 
from cleaned

{% endsnapshot %}