{{
    config(
        materialized = 'table',
        alias = 'lga_suburb'
    )
}}

select * from {{source("raw", "lga_suburb")}}
