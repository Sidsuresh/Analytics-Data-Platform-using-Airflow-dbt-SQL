{{
    config(
        alias = 'airbnb',
        materialized = 'table'
    )
}}

select * from {{source('raw', 'airbnb')}}