{{
    config(
        materialized = 'table',
        alias = 'lga_code'
    )
}}

select * from {{source("raw", "lga_code")}}
