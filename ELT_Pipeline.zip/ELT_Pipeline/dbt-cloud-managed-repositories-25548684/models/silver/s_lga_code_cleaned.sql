{{
    config(
        materialized = 'table',
        alias = 'lga_code_cleaned',
        unique_key = 'lga_code'
    )
}}

with source as (
    select * from {{ref("b_lga_code")}}
),

ranked as 
(
    select
        upper(trim(concat('LGA', trim(lga_code)))) as lga_code,
        initcap(trim(lga_name)) as lga_name,
        row_number() over (
            partition by upper(trim(concat('LGA', trim(lga_code))))
            order by lga_name desc
        ) as rn
    from source
)

select 
    lga_code,
    lga_name
from ranked
where rn = 1
order by lga_code



