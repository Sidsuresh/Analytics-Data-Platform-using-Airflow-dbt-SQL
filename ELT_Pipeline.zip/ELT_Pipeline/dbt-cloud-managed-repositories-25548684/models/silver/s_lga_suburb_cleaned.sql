{{
    config(
        materialized = 'table',
        unique_key = 'suburb_id',
        alias = 'lga_suburb_cleaned'
    )
}}

with suburb_clean as (
    select
        initcap(trim(suburb_name)) as suburb_name,
        initcap(trim(lga_name)) as lga_name
    from {{ ref('b_lga_suburb') }}
),

lga_code_clean as (
    select * from {{ref("s_lga_code_cleaned")}}
),

ranked as (
    select
        row_number() over (
            partition by s.lga_name, s.suburb_name
            order by s.lga_name, s.suburb_name
        ) as rn,
        lc.lga_code,
        s.lga_name,
        s.suburb_name
    from suburb_clean s
    left join lga_code_clean lc
        on lc.lga_name = s.lga_name
)

select
    {{ dbt_utils.generate_surrogate_key(['lga_name', 'suburb_name']) }} as suburb_id,
    lga_code,
    lga_name,
    suburb_name
from ranked
where rn = 1
order by lga_name, suburb_name