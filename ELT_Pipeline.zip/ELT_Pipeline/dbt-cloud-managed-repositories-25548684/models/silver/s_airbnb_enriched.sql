{{
    config(
        materialized = 'table',
        alias = 'airbnb_enriched',
        unique_key = 'record_id'
    )
}}

with 
airbnb_clean as 
(
    select * from {{ref("s_airbnb_cleaned")}}
),

lga_mapping as (
    select 
        a.*,
        coalesce(lga_code, 'LGA19499') as listing_neighbourhood_lga_code
    from airbnb_clean a
    left join {{ref("s_lga_code_cleaned")}} lc
    on a.listing_neighbourhood = lc.lga_name
)

select 
    lga.*,
    coalesce(ls.lga_name, 'No Usual Address') as hosting_neighbourhood_lga_name,
    coalesce(ls.lga_code, 'No Usual Address')  as hosting_neighbourhood_lga_code,
    coalesce(ls.suburb_id, 'No Usual Address') as hosting_neighbourhood_suburb_id
from lga_mapping lga
left join {{ref("s_lga_suburb_cleaned")}} ls
on lga.host_neighbourhood = ls.suburb_name

