{{
    config(
        materialized = 'table',
        alias = 'airbnb_cleaned',
        unique_key = 'record_id'
    )
}}

with source as (
    select
        *,
        cast(split_part(file_month, '_', 2) as integer) as file_year,
        cast(split_part(file_month, '_', 1) as integer) as file_month_num
    from {{ ref('b_airbnb') }}
),

ranked as (
    select *,
        row_number() over (partition by listing_id, scraped_date order by scraped_date desc) as rn
    from source
)

select
    {{ dbt_utils.generate_surrogate_key(['listing_id', 'scraped_date']) }} as record_id,
    cast(listing_id as bigint) as listing_id,
    coalesce(cast(scrape_id as bigint), -1) as scrape_id,
    to_date(nullif(trim(scraped_date), ''), 'YYYY-MM-DD') as scraped_date,
    coalesce(cast(host_id as bigint), -1) as host_id,
    coalesce(trim(host_name), 'Unknown Host')::text as host_name,
    to_date(nullif(trim(host_since), ''), 'DD/MM/YYYY') as host_since,
    case
        when lower(trim(host_is_superhost)) = 't' then true
        when lower(trim(host_is_superhost)) = 'f' then false
        else false
    end::boolean as host_is_superhost,
    coalesce(initcap(trim(host_neighbourhood)), 'No Usual Address')::text as host_neighbourhood,
    coalesce(initcap(trim(listing_neighbourhood)), 'No Usual Address')::text as listing_neighbourhood,
    coalesce(initcap(trim(property_type)), 'Unknown Property Type')::text as property_type,
    coalesce(initcap(trim(room_type)), 'Unknown Room Type')::text as room_type,
    coalesce(accommodates, 0)::bigint as accommodates,
    coalesce(price, 0)::numeric(10,2) as price,
    case 
        when lower(trim(has_availability)) = 't' then true
        when lower(trim(has_availability)) = 'f' then false
        else false 
    end::boolean as has_availability,
    coalesce(availability_30, 0)::bigint as availability_30,
    coalesce(number_of_reviews, 0)::bigint as number_of_reviews,
    case
    when trim(review_scores_rating::text) ilike 'nan' then 0.0
    else coalesce(review_scores_rating, 0.0)
end as review_scores_rating,

case
    when trim(review_scores_accuracy::text) ilike 'nan' then 0.0
    else coalesce(review_scores_accuracy, 0.0)
end as review_scores_accuracy,

case
    when trim(review_scores_cleanliness::text) ilike 'nan' then 0.0
    else coalesce(review_scores_cleanliness, 0.0)
end as review_scores_cleanliness,

case
    when trim(review_scores_checkin::text) ilike 'nan' then 0.0
    else coalesce(review_scores_checkin, 0.0)
end as review_scores_checkin,

case
    when trim(review_scores_communication::text) ilike 'nan' then 0.0
    else coalesce(review_scores_communication, 0.0)
end as review_scores_communication,

case
    when trim(review_scores_value::text) ilike 'nan' then 0.0
    else coalesce(review_scores_value, 0.0)
end as review_scores_value
from ranked
where rn = 1
    and extract(month from to_date(scraped_date, 'YYYY-MM-DD')) = file_month_num
    and extract(year from to_date(scraped_date, 'YYYY-MM-DD')) = file_year
order by listing_id, scraped_date