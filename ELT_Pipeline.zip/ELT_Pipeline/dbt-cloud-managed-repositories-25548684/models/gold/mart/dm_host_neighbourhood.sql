{{
    config(
        materialized='view',
        alias='dm_host_neighbourhood'
    )
}}


with fact as (
    select * from {{ref("g_fact_airbnb")}}
),
    
dim as (
    select * from {{ref("g_dim_host")}}
),

suburb as (
    select * from {{ref("g_dim_suburb")}}
),

agg as (
    select
        lga_name as host_neighbourhood_lga,
        extract(month from f.scraped_date)::int as month_sc, 
        extract(year from f.scraped_date)::int as year_sc,
        count(distinct d.host_id) as total_distinct_host,
        sum((30 - f.availability_30) * f.price) filter (where f.has_availability = true) as estimated_revenue_per_active_listing
    from fact f
    left join dim d
        on f.host_id = d.host_id
        and f.scraped_date >= d.valid_from
        and f.scraped_date < coalesce(d.valid_to, '9999-12-31'::timestamp)
    left join suburb s
        on f.suburb_id = s.suburb_id
    group by host_neighbourhood_lga, year_sc, month_sc
)

select 
    *,
    (estimated_revenue_per_active_listing / nullif(total_distinct_host, 0)) as estimated_revenue_per_host
from agg
where host_neighbourhood_lga is not null