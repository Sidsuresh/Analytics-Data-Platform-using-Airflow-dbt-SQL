{{
    config(
        materialized='view',
        alias='dm_listing_neighbourhood'
    )
}}


with fact as (
    select * from {{ref("g_fact_airbnb")}}
),
    
dim as (
    select * from {{ref("g_dim_property")}}
),

host as (
    select * from {{ref("g_dim_host")}}
),

agg as (
    select 
        d.listing_neighbourhood,
        count(*) filter (where f.has_availability = true) as active_listings,
        count(*) filter (where f.has_availability = false) as inactive_listings,
        count(*) as total_listings,
        min(f.price) filter (where f.has_availability = true) as minimum_price_active_listings,
        max(f.price) filter (where f.has_availability = true) as maximum_price_active_listings,
        percentile_cont(0.5) within group (order by price) filter (where has_availability = true) as median_price_active_listings,
        avg(f.price) filter (where f.has_availability = true) as average_price_active_listings,
        count(distinct h.host_id) as distinct_hosts,
        count(distinct h.host_id) filter (where h.host_is_superhost = true) as distinct_superhosts,
        avg(f.review_scores_rating) filter (where f.has_availability = true)::numeric as average_rating_active_listings,
        sum(30 - f.availability_30) filter (where f.has_availability = true) as total_stays_active_listings,
        sum((30 - f.availability_30) * f.price) filter (where f.has_availability = true) as estimated_revenue_per_active_listing,
        extract(month from f.scraped_date)::int as month_sc, 
        extract(year from f.scraped_date)::int as year_sc
    from fact f
    left join dim d
        on f.listing_id = d.listing_id
        and f.scraped_date >= d.valid_from
        and f.scraped_date < coalesce(d.valid_to, '9999-12-31'::timestamp)
    left join host h
        on f.host_id = h.host_id
        and f.scraped_date >= h.valid_from
        and f.scraped_date < coalesce(h.valid_to, '9999-12-31'::timestamp)
    group by d.listing_neighbourhood, year_sc, month_sc
),

pct_change as (
    select
        *,
        round((active_listings * 100.0 / NULLIF(total_listings, 0)), 3) as active_listing_rate,
        round((distinct_superhosts * 100.0 / NULLIF(distinct_hosts, 0)), 3) as superhost_rate,
        lag(active_listings) over (partition by listing_neighbourhood order by year_sc, month_sc) as prev_active,
        lag(inactive_listings) over (partition by listing_neighbourhood order by year_sc, month_sc) as prev_inactive
    from agg
)

select 
    listing_neighbourhood,
    month_sc,
    year_sc,
    active_listing_rate,
    minimum_price_active_listings,
    maximum_price_active_listings,
    median_price_active_listings,
    round(average_price_active_listings, 3) as average_price_active_listings,
    distinct_hosts,
    superhost_rate,
    round(average_rating_active_listings, 3) as average_rating_active_listings,
    round((active_listings - prev_active) * 100.0 / nullif(prev_active,0), 3) as pct_change_active_listings,
    round((inactive_listings - prev_inactive) * 100.0 / nullif(prev_inactive,0), 3)::float as pct_change_inactive_listings,
    total_stays_active_listings,
    round(estimated_revenue_per_active_listing * 1.0 / nullif(active_listings, 0), 3)::float as avg_estimated_revenue_per_active_listing
from pct_change
where listing_neighbourhood is not null