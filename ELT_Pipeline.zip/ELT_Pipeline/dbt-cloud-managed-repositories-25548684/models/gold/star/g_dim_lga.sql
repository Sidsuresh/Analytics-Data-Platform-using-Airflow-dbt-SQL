{{
    config(
        unique_key = 'lga_code',
        alias = 'dim_lga'
    )
}}

with 
source as (
    select * from {{ref("lga_snapshot")}}
),

cleaned as (
    select
        lga_code,
        lga_name,
        case
            when dbt_valid_from = (select min(dbt_valid_from) from source)
                then '2008-08-01'::date
            else dbt_valid_from
        end as valid_from,
        dbt_valid_to as valid_to
    from source
    where lga_code != 'LGA19499'
),

unknown_lga as (
    select
        'LGA19499' as lga_code,
        'No Usual Address' as lga_name,
        '2008-08-01'::date as valid_from,
        null::date as valid_to
)

select * from unknown_lga
union all
select * from cleaned