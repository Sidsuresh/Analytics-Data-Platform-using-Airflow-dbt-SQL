{{
    config(
        unique_key = 'host_id',
        alias = 'dim_host'
    )
}}

with
source as (
    select * from {{ref("host_snapshot")}}
), 

cleaned as (
    select
        host_id,
        host_name,
        host_neighbourhood,
        host_is_superhost,
        case
            when dbt_valid_from = (select min(dbt_valid_from) from source)
                then '2008-08-01'::date
            else dbt_valid_from
        end as valid_from,
        dbt_valid_to as valid_to
    from source
),

unknown_host as (
    select
        0 as host_id,
        'Unknown Host' as host_name,
        'No Usual Address' as host_neighbourhood,
        false as host_is_superhost,
        '2008-08-01'::date as valid_from,
        null::date as valid_to
)

select * from unknown_host
union all
select * from cleaned
order by host_id