{{
    config(
        unique_key = 'record_id',
        alias = 'fact_airbnb'
    )
}}

with source as (
    select * from {{ref("s_airbnb_enriched")}}
)

select 
    record_id,
    scraped_date,
    accommodates,
    price,
    has_availability,
    availability_30,
    number_of_reviews,
    review_scores_rating,
    review_scores_accuracy,
    review_scores_cleanliness,
    review_scores_checkin,
    review_scores_communication,
    review_scores_value,

    case
        when host_id in (select distinct host_id from {{ ref('g_dim_host') }})
            then host_id
        else 0
    end as host_id,

    case
        when listing_id in (select distinct listing_id from {{ ref('g_dim_property') }})
            then listing_id
        else 0
    end as listing_id,

    case
        when hosting_neighbourhood_suburb_id in (select distinct suburb_id from {{ ref('g_dim_suburb') }})
            then hosting_neighbourhood_suburb_id
        else 'No Usual Address'
    end as suburb_id,

    case
        when listing_neighbourhood_lga_code in (select distinct lga_code from {{ ref('g_dim_lga') }})
            then listing_neighbourhood_lga_code
        else 'LGA19499'
    end as lga_code
from source


