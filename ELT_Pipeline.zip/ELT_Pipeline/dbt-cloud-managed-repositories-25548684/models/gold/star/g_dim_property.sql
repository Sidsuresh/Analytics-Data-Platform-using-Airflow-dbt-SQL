{{
    config(
        unique_key = 'listing_id',
        alias = 'dim_property'
    )
}}

with 
source as 
(
    select * from {{ref("property_snapshot")}}
),

cleaned as (
    select 
        listing_id,
        property_type,
        room_type,
        listing_neighbourhood,
        host_id,
        case
            when dbt_valid_from = (select min(dbt_valid_from) from source)
                then '2008-08-01'::date
            else dbt_valid_from
        end as valid_from,
        dbt_valid_to as valid_to
    from source
),

unknown_property as (
    select
        0 as listing_id,
        'Unknown Property Type' as property_type,
        'Unknown Room Type' as room_type,
        'No Usual Address' as listing_neighbourhood,
        0 as host_id,
        '2008-08-01'::date as valid_from,
        null::date as valid_to
)

select * from unknown_property
union all
select * from cleaned
order by listing_id
