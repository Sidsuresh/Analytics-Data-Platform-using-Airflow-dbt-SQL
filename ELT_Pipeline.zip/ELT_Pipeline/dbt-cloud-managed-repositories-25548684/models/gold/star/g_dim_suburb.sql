{{
    config(
        unique_key = 'suburb_id',
        alias = 'dim_suburb'
    )
}}

with source as (
    select * from {{ref("suburb_snapshot")}}
), 

cleaned as (
    select
        suburb_id,
        lga_name,
        suburb_name,
        case
            when dbt_valid_from = (select min(dbt_valid_from) from source)
                then '2008-08-01'::date
            else dbt_valid_from
        end as valid_from,
        dbt_valid_to as valid_to
    from source 
),

unknown_suburb as (
    select 
        'No Usual Address' as suburb_id,
        'No Usual Address' as lga_name,
        'No Usual Address' as suburb_name,
        '2008-08-01'::date as valid_from,
        null::date as valid_to

)

select * from unknown_suburb
union all
select * from cleaned
